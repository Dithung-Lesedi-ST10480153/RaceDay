﻿
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using RaceDay.Data;

var builder = WebApplication.CreateBuilder(args);

// --------------------------------------------------
// 1. Register application services
// --------------------------------------------------

builder.Services.AddRazorPages();
builder.Services.AddControllers();

// --------------------------------------------------
// 2. Configure Swagger / API documentation
// --------------------------------------------------

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// --------------------------------------------------
// 3. Configure Oracle database
// --------------------------------------------------

var connectionString = builder.Configuration
    .GetConnectionString("RaceDayDb");

if (string.IsNullOrWhiteSpace(connectionString))
{
    throw new InvalidOperationException(
        "ConnectionStrings:RaceDayDb is missing from appsettings.json.");
}

builder.Services.AddDbContext<ApplicationDbContext>(options =>
{
    options.UseOracle(connectionString);
});

// --------------------------------------------------
// 4. Configure cookie authentication
// --------------------------------------------------

builder.Services
    .AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.Cookie.Name = "RaceDay.Auth";
        options.Cookie.HttpOnly = true;
        options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
        options.Cookie.SameSite = SameSiteMode.Lax;
        options.Cookie.Path = "/";

        options.ExpireTimeSpan = TimeSpan.FromHours(2);
        options.SlidingExpiration = true;

        // Return HTTP 401 instead of redirecting to login
        options.Events.OnRedirectToLogin = context =>
        {
            context.Response.StatusCode =
                StatusCodes.Status401Unauthorized;

            return Task.CompletedTask;
        };

        // Return HTTP 403 instead of redirecting to access denied
        options.Events.OnRedirectToAccessDenied = context =>
        {
            context.Response.StatusCode =
                StatusCodes.Status403Forbidden;

            return Task.CompletedTask;
        };
    });

// --------------------------------------------------
// 5. Configure authorization
// --------------------------------------------------

builder.Services.AddAuthorization();

// --------------------------------------------------
// 6. Build application
// --------------------------------------------------

var app = builder.Build();

// --------------------------------------------------
// 7. Global exception handling
// --------------------------------------------------

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

// --------------------------------------------------
// 8. Default home route
// --------------------------------------------------

app.MapGet("/", () =>
{
    return Results.Content(
        """
        <!DOCTYPE html>
        <html>
        <head>
            <title>RaceDay</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
        </head>
        <body style="font-family:Arial;padding:40px">
            <h1>RaceDay is working!</h1>
            <p>The application is running and the home route works.</p>
            <p><a href="/swagger">Open API documentation</a></p>
        </body>
        </html>
        """,
        "text/html");
});

// --------------------------------------------------
// 9. Configure Swagger (Development only)
// --------------------------------------------------

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// --------------------------------------------------
// 10. Configure middleware pipeline
// --------------------------------------------------

app.UseHttpsRedirection();

app.UseStaticFiles();

app.UseRouting();

// Authentication must come before authorization
app.UseAuthentication();

app.UseAuthorization();

// --------------------------------------------------
// 11. Map application endpoints
// --------------------------------------------------

// Razor Pages
app.MapRazorPages();

// REST API Controllers
app.MapControllers();

// --------------------------------------------------
// 12. Run application
// --------------------------------------------------

app.Run();
