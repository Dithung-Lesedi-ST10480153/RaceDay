
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RaceDay.Pages;

public class IndexModel : PageModel
{
    public void OnGet()
    {
    }
}
